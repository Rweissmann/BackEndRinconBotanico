INSERT INTO Plantas (idPlantas, Nombre, idCategorias, CategoriasDescripcion) VALUES (1,'Azucenita de Bañado', 1,'Acuaticas' ,
2, 'Achira Amarilla', 1,'Acuaticas', 3, 'Rosa de Rio', 1,'Acuaticas', 4, 'Aguape', 1,'Acuaticas', 5, 'Margarita del Bañado', 1,'Acuaticas', 6, 'Saeta', 1,'Acuaticas')


INSERT INTO Plantas (idPlantas, Nombre, idCategorias, CategoriasDescripción) VALUES (1001, 'Chinita del Campo', 2,'Exteriores', 1002, 'Margarita del Campo', 2,'Exteriores', 1003, 'Verbena de Buenos Aires', 2,'Exteriores', 1004, 'Ceibo', 2,'Exteriores',1005, 'Fumo Bravo', 2,'Exteriores', 1006, 'Maracuya', 2,'Exteriores')


INSERT INTO Plantas (idPlantas, Nombre, idCategorias, CategoriasDescripción) VALUES (2001, 'Croton', 3, 'Interiores', 2002, 'Estrella Federal', 3, 'Interiores', 2003, 'Fitonia', 3, 'Interiores', 2004, 'Helecho', 3,'Interiores', 2005, 'Potus', 3, 'Interiores', 2006, 'Sigonium', 3, 'Interiores')
