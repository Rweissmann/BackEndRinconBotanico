DELETE FROM plantas Where idPlantas=2010;
SELECT * FROM rinconbotanico.plantas;