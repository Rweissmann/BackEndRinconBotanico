DELETE FROM imagenes Where idPlantas = 2010;
SELECT * FROM rinconbotanico.imagenes;